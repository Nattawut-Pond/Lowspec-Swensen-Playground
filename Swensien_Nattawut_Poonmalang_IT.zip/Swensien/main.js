function openMenu(evt, menuName) {
    var i, menuContent, tablinks;

    // Hide all menu contents
    menuContent = document.getElementsByClassName("menu-content");
    for (i = 0; i < menuContent.length; i++) {
        menuContent[i].style.display = "none";
    }

    // Remove the active class from all tablinks
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab and add an active class to the clicked tab
    document.getElementById(menuName).style.display = "flex";
    evt.currentTarget.className += " active";
}


